require("prototypes.recipe.alien-science-recipes")
require("prototypes.technology.alien-science-technologies")