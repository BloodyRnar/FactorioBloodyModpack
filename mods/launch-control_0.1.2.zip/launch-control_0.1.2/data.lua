require("prototypes.research")
require("prototypes.lc")

data:extend{
  {
    type = "font",
    name = "lc-font",
    from = "default-bold",
    size = 14,
    border = true,
    border_color = {}
  },
}

data.raw["gui-style"].default["lc_icon"] =
{
    type = "button_style",
    parent = "button_style",
    
    width = 32,
    height = 32,
    
    font = "lc-font",
    align="right",
    top_padding = 10,
    right_padding = 3,
    bottom_padding = 0,
    left_padding = 3,
    --border_color = {r=0, g=1, b=0},

    default_graphical_set =
    {
        type = "monolith",
        monolith_image =
        {
            filename = "__launch-control__/graphics/icons/launch-control.png",
            priority = "extra-high-no-scale",
            width = 32,
            height = 32,
            x = 0
        }
    },
    hovered_graphical_set =
    {
        type = "monolith",
        monolith_image =
        {
            filename = "__launch-control__/graphics/icons/launch-control.png",
            priority = "extra-high-no-scale",
            width = 32,
            height = 32,
            x = 0
        }
    },
    clicked_graphical_set =
    {
        type = "monolith",
        monolith_image =
        {
            filename = "__launch-control__/graphics/icons/launch-control.png",
            width = 32,
            height = 32,
            x = 0
        }
    }
}

data.raw["gui-style"].default["lc_frame"] =
{
    type = "frame_style",
    minimal_width = 34,
    top_padding = 2,
    right_padding = 2,
    bottom_padding = 2,
    left_padding = 2,
    scalable = false, 
}


