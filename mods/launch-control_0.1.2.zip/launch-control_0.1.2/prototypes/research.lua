data:extend{
	{type = "technology",name="launch-control",
  icon = "__launch-control__/graphics/technology/launch-control.png",
	effects = 
	{
		{type = "unlock-recipe", recipe = "launch-control-center" },
	},
	prerequisites = {"rocket-silo"},
  unit =
  {
      count = 1000,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
	  order = "e-[radar]-a",
	}
}
