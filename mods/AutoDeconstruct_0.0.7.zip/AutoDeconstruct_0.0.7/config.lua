if not autodeconstruct then autodeconstruct = {} end

autodeconstruct.wait_for_robots = false
autodeconstruct.remove_target = true
