if not rq then rq = {} end
rq.big_icons = {}