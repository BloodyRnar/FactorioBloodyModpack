require("config")

if speedTech == true then

	require("prototypes.technology.robotspeed")
end
if capacityTech == true then

	require("prototypes.technology.robotcapacity")
end
if characterTech == true then

	require("prototypes.technology.logslots")
end
if trashTech == true then

	require("prototypes.technology.trashslots")
end