data:extend({
	{
		type = "recipe",
		name = "repair-module",
		enabled = false,
		energy_required = 10,
		ingredients = {
			{"smart-inserter", 2},
			{"repair-pack", 2},
			{"steel-plate", 3},
		},
		result = "repair-module"
	},
})
