require "config"

require "prototypes.item"
require "prototypes.recipe"
require "prototypes.equipment"
require "prototypes.technology"

data.raw["movement-bonus-equipment"]["repair-module"].energy_consumption = config.module_energy_consumption
