# AutoTrash

### Moves items to the trash slots automatically

More info: https://forums.factorio.com/viewtopic.php?f=97&t=16016
